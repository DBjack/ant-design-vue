import pl_PL from '../../date-picker/locale/pl_PL';
export default pl_PL;
