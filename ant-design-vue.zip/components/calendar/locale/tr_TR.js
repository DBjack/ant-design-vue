import tr_TR from '../../date-picker/locale/tr_TR';
export default tr_TR;
