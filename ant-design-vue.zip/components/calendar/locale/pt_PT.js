import pt_PT from '../../date-picker/locale/pt_PT';
export default pt_PT;
