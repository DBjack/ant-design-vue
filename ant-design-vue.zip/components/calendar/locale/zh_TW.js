import zh_TW from '../../date-picker/locale/zh_TW';
export default zh_TW;
