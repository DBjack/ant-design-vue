export const PREFIX_CLS = 'ant-fullcalendar';
