<cn>
#### 基本
最简单的用法。
</cn>

<us>
#### basic
The most basic usage.
</us>

```html
<template>
  <div>
    <a-back-top />
    Scroll down to see the bottom-right
    <strong style="color: rgba(64, 64, 64, 0.6)"> gray </strong>
    button.
  </div>
</template>
```
