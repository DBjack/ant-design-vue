import demoTest from '../../../tests/shared/demoTest';

demoTest('form', { suffix: 'vue', skip: ['index.vue', 'vuex.vue'] });
