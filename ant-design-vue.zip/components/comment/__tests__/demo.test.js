import demoTest from '../../../tests/shared/demoTest';

demoTest('comment');
