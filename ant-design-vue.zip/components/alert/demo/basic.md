<cn>
#### 基本
最简单的用法，适用于简短的警告提示。
</cn>

<us>
#### basic
The simplest usage for short messages.
</us>

```html
<template>
  <a-alert message="Success Text" type="success" />
</template>
```
