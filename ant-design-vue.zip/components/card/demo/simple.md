<cn>
#### 简洁卡片
只包含内容区域。
</cn>

<us>
#### Simple card
A simple card only containing a content area.
</us>

```html
<template>
  <a-card style="width: 300px">
    <p>Card content</p>
    <p>Card content</p>
    <p>Card content</p>
  </a-card>
</template>
```
