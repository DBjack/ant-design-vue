// empty file prevent babel-plugin-import error
import '../../style/index.less';
