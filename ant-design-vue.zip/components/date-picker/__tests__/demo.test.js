import demoTest from '../../../tests/shared/demoTest';

demoTest('date-picker');
