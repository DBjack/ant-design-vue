---
name: "⚠️  Please use issue-helper ⚠️"
about: The issue which is not created via https://vuecomponent.github.io/issue-helper/ will be closed
  immediately.
labels:

---

The issue which is not created via https://vuecomponent.github.io/issue-helper/ will be closed immediately.

---

注意：不是用 https://vuecomponent.github.io/issue-helper/ 或 http://ant-design-vue.gitee.io/issue-helper/ 创建的 issue 会被立即关闭。
